"""Start a new session: detect state, assign role, create session folder, print instructions.

Single entry point for every session. Combines role assignment + basic verification.

Implements cold-start detection:
  - BLOCKED: goal.md is template → exit with error
  - BOOTSTRAP: 0 completed sessions → scaffold + seed + first research
  - SEEDING: 1-3 completed sessions → force core-worker
  - NORMAL: 4+ completed sessions → dice roll

Usage:
    python scripts/session/session_start.py                    # Auto-detect state
    python scripts/session/session_start.py --force reviewer   # Human override
    python scripts/session/session_start.py --force bootstrap  # Force bootstrap
"""

from __future__ import annotations

import argparse
import contextlib
import random
import re
import shutil
import sys
from pathlib import Path

SESSIONS_DIR = Path("engine/sessions")
PROCESS_DIR = Path("engine/process")

ROLES = ["core-worker", "reviewer", "backlog-worker", "goal-alignment", "spec-writer", "bootstrap"]

# Phase-based weights: shift as knowledge base matures
# Breadth phase (< 20 sessions): heavy core-worker to fill wiki categories
# Depth phase (20+ sessions): heavy spec-writer to formalize into specs
WEIGHTS_BREADTH = [0.45, 0.15, 0.15, 0.10, 0.15]
WEIGHTS_DEPTH = [0.25, 0.15, 0.10, 0.10, 0.40]
DEPTH_THRESHOLD = 20

COMPLETED_THRESHOLD = 300  # bytes — anchor file must exceed this to count as "completed"
SEEDING_COUNT = 4  # force core-worker until this many sessions completed


def goal_is_template() -> bool:
    goal = Path("goal.md")
    if not goal.exists():
        return True
    content = goal.read_text(encoding="utf-8", errors="ignore")
    return "<!-- " in content[:500]


def count_completed_sessions() -> int:
    if not SESSIONS_DIR.exists():
        return 0
    count = 0
    for d in SESSIONS_DIR.iterdir():
        if not d.is_dir() or not d.name[:4].isdigit():
            continue
        for f in ["findings.md", "report.md", "state.md"]:
            fp = d / f
            if fp.exists() and fp.stat().st_size > COMPLETED_THRESHOLD:
                count += 1
                break
    return count


def determine_role(force: str | None) -> tuple[str, str]:
    if force:
        return force, "forced"
    if goal_is_template():
        return "blocked", "goal.md not configured"
    completed = count_completed_sessions()
    if completed == 0:
        return "bootstrap", "cold-start: first run"
    if completed < SEEDING_COUNT:
        return "core-worker", f"seeding: {completed}/{SEEDING_COUNT} completed sessions"
    return roll_dice(), ""


def roll_dice() -> str:
    roles = ["core-worker", "reviewer", "backlog-worker", "goal-alignment", "spec-writer"]
    completed = count_completed_sessions()
    weights = WEIGHTS_DEPTH if completed >= DEPTH_THRESHOLD else WEIGHTS_BREADTH
    r = random.random()  # noqa: S311
    cumulative = 0.0
    for role, weight in zip(roles, weights, strict=False):
        cumulative += weight
        if r < cumulative:
            return role
    return roles[-1]


def next_session_id() -> int:
    if not SESSIONS_DIR.exists():
        return 1
    existing = []
    for d in SESSIONS_DIR.iterdir():
        if d.is_dir() and d.name[:4].isdigit():
            with contextlib.suppress(ValueError):
                existing.append(int(d.name[:4]))
    if not existing:
        return 1

    latest_id = max(existing)
    latest_dirs = [d for d in SESSIONS_DIR.iterdir() if d.is_dir() and d.name.startswith(f"{latest_id:04d}")]
    if latest_dirs:
        latest_dir = latest_dirs[0]
        main_file = latest_dir / "findings.md"
        if not main_file.exists():
            main_file = latest_dir / "report.md"
        if main_file.exists() and main_file.stat().st_size < 100:
            shutil.rmtree(latest_dir)
            return latest_id

    return latest_id + 1


def create_session_folder(session_id: int, role: str) -> Path:
    folder_name = f"{session_id:04d}-{role}"
    session_dir = SESSIONS_DIR / folder_name
    session_dir.mkdir(parents=True, exist_ok=True)

    if role in ("core-worker", "bootstrap"):
        (session_dir / "findings.md").write_text(
            "# Findings\n\n## Vision\n\n## Reality\n\n## Alignment\n\n## Wiki Pages Written\n\n## Friction\n"
        )
    elif role == "goal-alignment":
        (session_dir / "state.md").write_text("# State Assessment\n\n")
        (session_dir / "priorities.md").write_text("# Priorities\n\n")
    else:
        (session_dir / "report.md").write_text(
            f"# {role.replace('-', ' ').title()} Report — Session {session_id:04d}\n\n"
        )

    return session_dir


def find_last_session(exclude_id: int | None = None) -> str | None:
    if not SESSIONS_DIR.exists():
        return None
    sessions = sorted(
        [d for d in SESSIONS_DIR.iterdir() if d.is_dir() and d.name[:4].isdigit()],
        key=lambda d: d.name,
        reverse=True,
    )
    for s in sessions:
        try:
            sid = int(s.name[:4])
            if sid == exclude_id:
                continue
        except ValueError:
            pass
        for f in ["findings.md", "report.md", "state.md"]:
            fp = s / f
            if fp.exists() and fp.stat().st_size > 50:
                return s.name
    return None


def print_instructions(role: str, session_dir: Path, session_id: int):
    print("\n[do]")

    if role == "bootstrap":
        print("  1. Create wiki taxonomy (folders matching goal.md categories):")
        print("     $ mkdir -p wiki/docs/{order-processing,inventory,shipping,payments,returns}")
        print("  2. Seed research backlog in engine/backlogs/ with 5-10 independent topics")
        print("  3. Do ONE abbreviated research pass — pick highest-priority topic")
        print("  4. Write findings.md (Vision + Reality + Alignment) + 1 wiki page")
        print("  5. Validate:")
        print(f"     $ uv run python scripts/session/validate_session.py {session_dir}/")

    elif role == "core-worker":
        print("  1. Pick a research topic (check backlogs or identify wiki gaps)")
        print("  2. Read what ALREADY EXISTS — identify the GAP you'll fill")
        print("  3. Research: Vision (standards, docs) + Reality (APIs, implementations)")
        print("  4. Write findings.md (Vision / Reality / Alignment)")
        print("  5. Write/update wiki pages with ## Sources sections")
        print("  6. File friction to backlogs/ if encountered")
        print("  7. Validate:")
        print(f"     $ uv run python scripts/session/validate_session.py {session_dir}/")

    elif role == "reviewer":
        last = find_last_session(exclude_id=session_id)
        if last:
            print(f"   Target: {last}")
            print()
            print("  1. Read target session output + git diff")
            print("  2. Audit: grounding, accuracy, completeness, spec-readiness")
            print("  3. Create backlog items for each gap found")
            print("  4. Write report.md")
            print("  5. Validate:")
            print(f"     $ uv run python scripts/session/validate_session.py {session_dir}/")
        else:
            print("  No previous session. Do process audit instead:")
            print("  1. Read each playbook + paradigms.md")
            print("  2. Create backlog items for ambiguities or missing automation")
            print("  3. Write report.md")
            print("  4. Validate:")
            print(f"     $ uv run python scripts/session/validate_session.py {session_dir}/")

    elif role == "backlog-worker":
        print("  1. Read backlogs (tooling.md, validation.md, process.md)")
        print("  2. Pick highest-value items (prefer validation > tooling > process)")
        print("  3. Implement fixes")
        print("  4. Mark items REALIZED with citation")
        print("  5. Write report.md")
        print("  6. Validate:")
        print(f"     $ uv run python scripts/session/validate_session.py {session_dir}/")

    elif role == "goal-alignment":
        print("  1. Read goal.md — understand the full mission")
        print("  2. Measure wiki state: pages per category, depth")
        print("  3. Write state.md — progress against subgoals")
        print("  4. Write priorities.md — ranked gaps")
        print("  5. Update backlogs to steer future sessions")
        print("  6. Validate:")
        print(f"     $ uv run python scripts/session/validate_session.py {session_dir}/")

    elif role == "spec-writer":
        print("  1. Check spec coverage (rules, tests per wiki category)")
        print("  2. Target lowest-coverage category")
        print("  3. Read wiki pages for that category")
        print("  4. Extract rules → Rules.md, data model → DBDesign.md, tests → TestCases/")
        print("  5. Write report.md")
        print("  6. Validate:")
        print(f"     $ uv run python scripts/session/validate_session.py {session_dir}/")


def main():
    parser = argparse.ArgumentParser(description="Start a new session")
    parser.add_argument("--force", choices=ROLES, help="Force a specific role")
    args = parser.parse_args()

    role, reason = determine_role(args.force)

    if role == "blocked":
        print("\n[blocked]")
        print("  goal.md still contains unfilled template markers.")
        print("  Configure goal.md before any session can begin.")
        sys.exit(1)

    session_id = next_session_id()
    session_dir = create_session_folder(session_id, role)

    # Print assignment
    print(f"\n Session {session_id:04d} — Role: {role}")
    if reason and reason != "forced":
        print(f"   ({reason})")
    print(f"   Folder: {session_dir}/")

    # Domain context
    goal_file = Path("goal.md")
    if goal_file.exists():
        goal_content = goal_file.read_text(encoding="utf-8", errors="ignore")
        mission_match = re.search(r"## Mission\s*\n+(.+)", goal_content)
        if mission_match:
            print(f"   Domain: {mission_match.group(1).strip()[:80]}")

    # Role instructions
    print_instructions(role, session_dir, session_id)

    # Reference
    print("\n[ref]")
    print("  goal:      goal.md")
    print("  paradigms: engine/process/paradigms.md")
    playbook = "bootstrap" if role == "bootstrap" else role
    print(f"  playbook:  engine/process/playbook-{playbook}.md")
    print()


if __name__ == "__main__":
    main()
