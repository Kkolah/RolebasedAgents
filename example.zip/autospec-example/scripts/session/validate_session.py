"""Validate a session folder meets minimum quality bar.

Checks:
  - Session folder exists and has expected structure
  - Anchor file (findings.md / report.md / state.md) has substantive content
  - Wiki pages written have ## Sources section (for core-worker/bootstrap)
  - Backlog items reference session ID (for reviewer/backlog-worker)

Usage:
    python scripts/session/validate_session.py engine/sessions/0001-core-worker/
"""

from __future__ import annotations

import sys
from pathlib import Path

MIN_CONTENT_BYTES = 300


def validate_session(session_path: Path) -> list[tuple[bool, str]]:
    results: list[tuple[bool, str]] = []

    # Check folder exists
    if not session_path.is_dir():
        results.append((False, f"Session folder not found: {session_path}"))
        return results
    results.append((True, f"Session folder exists: {session_path.name}"))

    # Extract role from folder name
    parts = session_path.name.split("-", 1)
    if len(parts) < 2:
        results.append((False, "Cannot determine role from folder name"))
        return results

    session_id = parts[0]
    role = parts[1]

    # Check anchor file
    if role in ("core-worker", "bootstrap"):
        anchor = session_path / "findings.md"
        anchor_name = "findings.md"
    elif role == "goal-alignment":
        anchor = session_path / "state.md"
        anchor_name = "state.md"
    else:
        anchor = session_path / "report.md"
        anchor_name = "report.md"

    if not anchor.exists():
        results.append((False, f"Missing anchor file: {anchor_name}"))
    elif anchor.stat().st_size < MIN_CONTENT_BYTES:
        results.append((
            False,
            f"{anchor_name} too small ({anchor.stat().st_size} bytes, need {MIN_CONTENT_BYTES}+). "
            f"Add substantive content — Vision/Reality/Alignment sections with findings.",
        ))
    else:
        results.append((True, f"{anchor_name} has substantive content ({anchor.stat().st_size} bytes)"))

    # Role-specific checks
    if role in ("core-worker", "bootstrap"):
        # Check that wiki pages have ## Sources
        wiki_dir = Path("wiki/docs")
        if wiki_dir.exists():
            wiki_pages = list(wiki_dir.rglob("*.md"))
            pages_without_sources = []
            for page in wiki_pages:
                if page.name == "index.md":
                    continue
                content = page.read_text(encoding="utf-8", errors="ignore")
                if "## Sources" not in content:
                    pages_without_sources.append(str(page))
            if pages_without_sources and len(pages_without_sources) <= 3:
                results.append((
                    False,
                    f"Wiki pages missing ## Sources: {', '.join(pages_without_sources[:3])}",
                ))
            else:
                results.append((True, "Wiki pages have ## Sources sections"))

    elif role in ("reviewer", "backlog-worker"):
        # Check that backlog items reference this session
        backlogs_dir = Path("engine/backlogs")
        found_reference = False
        if backlogs_dir.exists():
            for bl in backlogs_dir.glob("*.md"):
                content = bl.read_text(encoding="utf-8", errors="ignore")
                if f"session {session_id}" in content.lower() or f"session {int(session_id):04d}" in content:
                    found_reference = True
                    break

        # Also check for "Friction: None" in findings/report
        if not found_reference and anchor.exists():
            content = anchor.read_text(encoding="utf-8", errors="ignore")
            if "friction" in content.lower() and "none" in content.lower():
                found_reference = True

        if not found_reference:
            results.append((
                False,
                f"No backlog item references session {session_id} AND no 'Friction: None' in {anchor_name}. "
                f"Fix: add '- **Filed by:** session {session_id}' to an item in engine/backlogs/, "
                f"OR add '## Friction\\nNone this session.' to {anchor_name}",
            ))
        else:
            results.append((True, "Session contribution tracked"))

    return results


def main():
    if len(sys.argv) < 2:
        print("Usage: python scripts/session/validate_session.py <session-folder-path>")
        sys.exit(1)

    session_path = Path(sys.argv[1])
    results = validate_session(session_path)

    print(f"\n Validation: {session_path.name}")
    print("─" * 60)

    all_pass = True
    for ok, msg in results:
        icon = "✅" if ok else "❌"
        print(f"  {icon} {msg}")
        if not ok:
            all_pass = False

    print()
    if all_pass:
        print("  ✅ All checks passed")
    else:
        print("  ❌ Some checks failed — fix issues above")
        sys.exit(1)


if __name__ == "__main__":
    main()
