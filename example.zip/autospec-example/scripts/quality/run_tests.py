"""Run quality checks (placeholder for test suite)."""

import subprocess
import sys


def main():
    print("Running quality checks...")
    result = subprocess.run(
        ["ruff", "check", "scripts/"],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        print("✅ All checks passed")
    else:
        print("❌ Issues found:")
        print(result.stdout)
        sys.exit(1)


if __name__ == "__main__":
    main()
