# AutoSpec Example — E-Commerce Order Fulfillment

*Demonstration of the AutoSpec methodology: autonomous specification extraction via self-improving agent loops.*

## What Is This?

This is a **working example** of the AutoSpec pattern applied to an e-commerce order fulfillment domain. It demonstrates how autonomous agents can:

1. **Research** domain knowledge from public sources
2. **Synthesize** findings into a structured wiki (Vision/Reality/Alignment layers)
3. **Extract** implementation-ready specifications (business rules, DB design, test cases)
4. **Self-improve** through role-based review and backlog management

## The Self-Improving Loop

Each session is assigned a role via weighted dice roll. Five specialized roles form a closed improvement loop:

| Role | Job | Weight |
|------|-----|--------|
| **Core Worker** | Research domain knowledge from sources | 45% |
| **Spec Writer** | Synthesize wiki into specs (rules, tests, architecture) | 15% |
| **Reviewer** | Audit prior sessions, find gaps, create backlog items | 15% |
| **Backlog Worker** | Implement tooling/process fixes from backlog | 15% |
| **Goal Alignment** | Assess coverage, steer priorities, measure progress | 10% |

Weights auto-shift by phase: Breadth (Core Worker 45%) → Depth (Spec Writer 40%).

## Domain: Order Fulfillment

```
Order Placement → Inventory Reservation → Payment Auth
→ Pick & Pack → Carrier Selection → Shipment → Delivery
→ (Optional) Return → Restock → Refund
```

## Current Output

| Artifact | Count |
|----------|-------|
| Business rules | 15 |
| Test cases | 10 |
| Wiki pages | 3 (with V/R/A analysis) |
| DB tables designed | 8 |

## Quick Start

```bash
# Prerequisites: uv, just
brew install uv just

# Run a session
cd autospec-example
just roll          # Assigns role, creates session folder, prints instructions

# Or run autonomous loop
just loop 5        # 5 autonomous sessions back-to-back
```

## Project Structure

```
├── goal.md                 Mission definition (edit this for your domain)
├── engine/
│   ├── process/            Paradigms + 5 role playbooks
│   ├── backlogs/           Improvement items
│   └── sessions/           Session output
├── wiki/docs/              Grounded domain knowledge
├── specs/                  Velocity V2 specifications
│   ├── 1-initial/          Rules, PRD
│   ├── 2-design/           Architecture, DB Design
│   ├── 3-eval/             Test Cases
│   └── governance/         Constraints (Forbidden Zones, Allowed Patterns)
└── scripts/                Session management automation
```

## Adapting to Your Domain

1. Edit `goal.md` with your domain mission, scope, and taxonomy
2. Update wiki category folders to match your taxonomy
3. Run `just roll` — the system bootstraps itself from there

The methodology is domain-agnostic. Replace "e-commerce" with any domain that has:
- Discoverable sources (APIs, docs, standards)
- Business rules to extract
- Implementation specs to produce

## Key Concepts

- **V/R/A Layers**: Every wiki page has Vision (how should it work), Reality (how does it work), Alignment (gaps)
- **Grounded Claims**: No assertion without a source link
- **Enforcement Hierarchy**: Validation > Tool > Reflection > Process
- **Phase Shifting**: System automatically biases toward breadth early, depth later
