# Architecture

## Module Decomposition

```
┌─────────────────────────────────────────────────────┐
│                    API Gateway                        │
│          (REST endpoints, auth, validation)           │
└───────────┬────────────┬────────────┬───────────────┘
            │            │            │
     ┌──────▼──────┐ ┌──▼───────┐ ┌─▼──────────┐
     │ OrderService│ │InventoryS│ │ShippingServ │
     │             │ │           │ │             │
     │ - create    │ │ - reserve │ │ - rate_shop │
     │ - confirm   │ │ - release │ │ - select    │
     │ - cancel    │ │ - query   │ │ - label     │
     └──────┬──────┘ └──┬───────┘ └─┬──────────┘
            │            │            │
     ┌──────▼──────┐    │     ┌──────▼──────┐
     │PaymentServ  │    │     │ CarrierAPI   │
     │             │    │     │ (external)   │
     │ - authorize │    │     └─────────────┘
     │ - capture   │    │
     │ - refund    │    │
     └─────────────┘    │
                   ┌────▼────────┐
                   │  Database   │
                   │ (PostgreSQL)│
                   └─────────────┘
```

## Service Boundaries

| Service | Responsibility | Dependencies |
|---------|---------------|--------------|
| OrderService | Order lifecycle, state transitions | InventoryService, PaymentService |
| InventoryService | Stock tracking, reservations | Database only (leaf service) |
| ShippingService | Carrier selection, label gen | CarrierAPI (external) |
| PaymentService | Auth, capture, refund | Stripe API (external) |

## Event Flow: Order Placement

```
1. Customer submits order
2. OrderService.create() → validates items, calculates totals
3. PaymentService.authorize() → Stripe creates payment intent
4. InventoryService.soft_reserve() → ATP decremented atomically
5. Order status → CONFIRMED
6. (async) Schedule: convert soft → hard after payment settles
```

## Event Flow: Shipment

```
1. Warehouse picks items → OrderService.start_processing()
2. InventoryService.convert_to_hard() → soft → hard reservation
3. ShippingService.rate_shop() → select cheapest carrier meeting SLA
4. ShippingService.create_label() → carrier API generates label
5. PaymentService.capture() → capture authorized amount
6. Order status → SHIPPED
```

## Key Design Decisions

1. **Reservation is synchronous** at order placement (not eventual). Prevents overselling.
2. **Payment capture is at shipment**, not order placement. Industry standard for e-commerce.
3. **Carrier selection is per-shipment**, not per-order. Supports partial shipments.
4. **All amounts stored as DECIMAL**, never float. Currency math requires precision.
