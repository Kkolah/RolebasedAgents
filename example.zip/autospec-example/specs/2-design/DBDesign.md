# Database Design

## Entity-Relationship Overview

```
orders ──< line_items >── products
  │                          │
  │                          │
  ├── payments            inventory
  │                          │
  └── shipments ──< shipment_items
         │
         └── carrier_services
```

---

## Tables

### orders
| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | Order identifier |
| customer_id | UUID | NOT NULL, FK | Customer reference |
| status | ENUM | NOT NULL | PLACED, CONFIRMED, PROCESSING, SHIPPED, DELIVERED, CLOSED, CANCELLED |
| subtotal | DECIMAL(12,2) | NOT NULL | Before tax/shipping |
| tax_amount | DECIMAL(12,2) | NOT NULL DEFAULT 0 | Calculated tax |
| shipping_amount | DECIMAL(12,2) | NOT NULL DEFAULT 0 | Shipping cost |
| total | DECIMAL(12,2) | NOT NULL | subtotal + tax + shipping |
| currency | CHAR(3) | NOT NULL DEFAULT 'USD' | ISO 4217 |
| partial_shipment | BOOLEAN | NOT NULL DEFAULT FALSE | Customer opt-in |
| placed_at | TIMESTAMPTZ | NOT NULL | Order placement time |
| confirmed_at | TIMESTAMPTZ | NULL | Payment authorization time |
| cancelled_at | TIMESTAMPTZ | NULL | Cancellation time (if applicable) |
| created_at | TIMESTAMPTZ | NOT NULL DEFAULT NOW() | |
| updated_at | TIMESTAMPTZ | NOT NULL DEFAULT NOW() | |

### line_items
| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | |
| order_id | UUID | NOT NULL, FK → orders | |
| product_id | UUID | NOT NULL, FK → products | |
| sku | VARCHAR(50) | NOT NULL | SKU at time of order |
| quantity | INTEGER | NOT NULL, CHECK > 0 | |
| unit_price | DECIMAL(12,2) | NOT NULL | Price at time of order |
| status | ENUM | NOT NULL DEFAULT 'PENDING' | PENDING, RESERVED, SHIPPED, DELIVERED |

### products
| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | |
| sku | VARCHAR(50) | UNIQUE, NOT NULL | |
| name | VARCHAR(255) | NOT NULL | |
| weight_oz | DECIMAL(8,2) | NOT NULL | Actual weight in ounces |
| length_in | DECIMAL(6,2) | NULL | Package dimension |
| width_in | DECIMAL(6,2) | NULL | Package dimension |
| height_in | DECIMAL(6,2) | NULL | Package dimension |
| backorder_allowed | BOOLEAN | NOT NULL DEFAULT FALSE | |
| active | BOOLEAN | NOT NULL DEFAULT TRUE | |

### inventory
| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | |
| product_id | UUID | NOT NULL, FK → products | |
| warehouse_id | UUID | NOT NULL, FK → warehouses | |
| physical_stock | INTEGER | NOT NULL DEFAULT 0 | Total on-hand |
| hard_reserved | INTEGER | NOT NULL DEFAULT 0 | Committed to confirmed orders |
| soft_reserved | INTEGER | NOT NULL DEFAULT 0 | Held for unconfirmed orders |
| CONSTRAINT | | CHECK | physical_stock >= hard_reserved + soft_reserved (when backorder=false) |

**Derived:** `atp = physical_stock - hard_reserved - soft_reserved`

### reservations
| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | |
| order_id | UUID | NOT NULL, FK → orders | |
| product_id | UUID | NOT NULL, FK → products | |
| warehouse_id | UUID | NOT NULL, FK → warehouses | |
| quantity | INTEGER | NOT NULL, CHECK > 0 | |
| type | ENUM | NOT NULL | SOFT, HARD |
| expires_at | TIMESTAMPTZ | NULL | Only for SOFT (30 min default) |
| created_at | TIMESTAMPTZ | NOT NULL DEFAULT NOW() | |

### warehouses
| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | |
| name | VARCHAR(100) | NOT NULL | |
| timezone | VARCHAR(50) | NOT NULL | e.g., 'America/New_York' |
| zip_code | VARCHAR(10) | NOT NULL | Origin for zone calculation |
| active | BOOLEAN | NOT NULL DEFAULT TRUE | |

### shipments
| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | |
| order_id | UUID | NOT NULL, FK → orders | |
| carrier_service_id | UUID | NOT NULL, FK → carrier_services | |
| tracking_number | VARCHAR(100) | NULL | |
| label_url | VARCHAR(500) | NULL | |
| weight_oz | DECIMAL(8,2) | NOT NULL | Actual package weight |
| status | ENUM | NOT NULL DEFAULT 'PENDING' | PENDING, LABEL_CREATED, PICKED_UP, IN_TRANSIT, DELIVERED |
| shipped_at | TIMESTAMPTZ | NULL | |
| delivered_at | TIMESTAMPTZ | NULL | |
| created_at | TIMESTAMPTZ | NOT NULL DEFAULT NOW() | |

### carrier_services
| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | |
| carrier | VARCHAR(50) | NOT NULL | e.g., 'UPS', 'USPS', 'FedEx' |
| service_level | VARCHAR(50) | NOT NULL | e.g., 'Ground', 'Express', 'Overnight' |
| dim_weight_divisor | INTEGER | NOT NULL | 139 (UPS/FedEx), 166 (USPS) |
| cutoff_time | TIME | NOT NULL | Local warehouse time |
| active | BOOLEAN | NOT NULL DEFAULT TRUE | |

### payments
| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | |
| order_id | UUID | NOT NULL, FK → orders | |
| external_id | VARCHAR(255) | NOT NULL | Stripe payment intent ID |
| status | ENUM | NOT NULL | AUTHORIZED, CAPTURED, REFUNDED, PARTIALLY_REFUNDED, EXPIRED |
| authorized_amount | DECIMAL(12,2) | NOT NULL | |
| captured_amount | DECIMAL(12,2) | NOT NULL DEFAULT 0 | |
| refunded_amount | DECIMAL(12,2) | NOT NULL DEFAULT 0 | |
| currency | CHAR(3) | NOT NULL DEFAULT 'USD' | |
| authorized_at | TIMESTAMPTZ | NOT NULL | |
| captured_at | TIMESTAMPTZ | NULL | |
| expires_at | TIMESTAMPTZ | NOT NULL | Auth hold expiry (7 days) |

---

## Indexes

```sql
CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_line_items_order ON line_items(order_id);
CREATE INDEX idx_inventory_product_warehouse ON inventory(product_id, warehouse_id);
CREATE INDEX idx_reservations_order ON reservations(order_id);
CREATE INDEX idx_reservations_expires ON reservations(expires_at) WHERE type = 'SOFT';
CREATE INDEX idx_shipments_order ON shipments(order_id);
CREATE INDEX idx_payments_order ON payments(order_id);
```

---

## Constraints Summary

- `inventory.physical_stock >= hard_reserved + soft_reserved` (enforced at application layer for backorder-allowed products)
- `payments.refunded_amount <= payments.captured_amount` (RULE-015)
- `reservations.expires_at` is set only for SOFT type
- `orders.total = orders.subtotal + orders.tax_amount + orders.shipping_amount`
