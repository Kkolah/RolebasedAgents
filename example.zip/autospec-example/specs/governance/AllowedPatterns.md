# Allowed Patterns

> Approved architectural patterns. Use these. Don't invent alternatives.

---

## Service Layer Pattern

All business logic lives in service classes. No logic in controllers/routes or ORM models.

```python
class OrderService:
    def __init__(self, inventory: InventoryService, payment: PaymentService):
        self._inventory = inventory
        self._payment = payment

    def create_order(self, items: list[OrderItem]) -> Order:
        # Business logic here
        ...
```

## Dependency Injection

Services receive dependencies through constructor injection. No global state, no service locators.

## Repository Pattern for Data Access

Database access is abstracted behind repository interfaces. Services don't know about SQL.

```python
class OrderRepository(Protocol):
    def get(self, order_id: UUID) -> Order | None: ...
    def save(self, order: Order) -> None: ...
    def find_by_status(self, status: OrderStatus) -> list[Order]: ...
```

## Event-Driven for Cross-Service Communication

When Service A needs to notify Service B without coupling:
- Publish domain event (e.g., `OrderConfirmed`, `PaymentCaptured`)
- Subscriber handles asynchronously

## Configuration Over Code

Thresholds, timeouts, rates, and business parameters come from config:
- Fraud review threshold ($1,000)
- Reservation timeout (30 minutes)
- Shipping cutoff times (per carrier)
- Free shipping threshold ($50)

## Idempotency Keys

All external API calls (payment, carrier) use idempotency keys to prevent duplicate operations on retry.

## Decimal for Money

```python
from decimal import Decimal

subtotal = Decimal("49.99")  # YES
subtotal = 49.99             # FORBIDDEN (ForbiddenZone #2)
```
