# Spec Governance

## Spec States

```
DRAFT → REVIEW → APPROVED → FROZEN
```

- **DRAFT**: Being written by Spec Writer. May change at any time.
- **REVIEW**: Ready for human review. No agent changes allowed.
- **APPROVED**: Reviewed and accepted. Implementation agents may consume.
- **FROZEN**: Locked. Changes require explicit unlock + re-review.

## Rules for Agents

1. Only write to DRAFT specs (or create new ones as DRAFT)
2. Never modify APPROVED or FROZEN specs
3. If a wiki finding contradicts an APPROVED spec, file a backlog item — don't change the spec
4. Every rule must cite its wiki source
5. Every test case must cite the rule it validates
