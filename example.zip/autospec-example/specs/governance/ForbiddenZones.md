# Forbidden Zones

> Actions that are NEVER acceptable. No exception. Any agent that violates these is producing invalid output.

---

## Data Integrity

1. **No direct SQL writes** — All data modifications go through service layer. No raw INSERT/UPDATE/DELETE in application code.
2. **No floating-point currency** — All monetary amounts use DECIMAL. Never `float` or `double` for money.
3. **No negative ATP** — System must reject operations that would make Available-to-Promise negative (unless backorder explicitly enabled).

## Business Logic

4. **No capture without authorization** — Payment capture MUST have a valid, non-expired authorization.
5. **No shipment without reservation** — Cannot generate shipping label for items without hard reservation.
6. **No refund exceeding capture** — Total refunds ≤ total captured amount. Always.

## Security

7. **No stored card numbers** — PCI-DSS compliance. Use tokenized payment references only.
8. **No hardcoded prices** — All prices, thresholds, and rates come from configuration or database. Never in code.
9. **No secrets in code** — API keys, passwords in environment variables only.

## Process

10. **No wiki claims without sources** — Every assertion links to a verifiable source.
11. **No spec rules without wiki grounding** — Rules must trace back to researched wiki content.
