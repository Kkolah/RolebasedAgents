# Business Rules

> Extracted from wiki/docs/ research. Each rule is a testable invariant.

---

## Order Processing

### RULE-001: Fraud review threshold
- **Category:** order-processing
- **Statement:** Orders with total amount > $1,000 MUST undergo fraud review before confirmation.
- **Source:** wiki/docs/order-processing/order-lifecycle.md (Vision: transition gates)
- **Test approach:** Create order at $999.99 (auto-confirm) and $1,000.01 (held for review)

### RULE-002: Cancellation window
- **Category:** order-processing
- **Statement:** Orders can only be cancelled within 30 minutes of placement OR before pick begins (whichever comes first).
- **Source:** wiki/docs/order-processing/order-lifecycle.md (Alignment: time + event based)
- **Test approach:** Attempt cancel at 29 min (success), 31 min (fail), during pick (fail)

### RULE-003: Order state immutability after shipment
- **Category:** order-processing
- **Statement:** Once an order reaches SHIPPED state, it cannot be cancelled. Returns process must be used instead.
- **Source:** wiki/docs/order-processing/order-lifecycle.md (Vision: transition rules)
- **Test approach:** Attempt cancel on SHIPPED order (must fail with appropriate error)

### RULE-004: Partial shipment opt-in
- **Category:** order-processing
- **Statement:** Partial shipments are allowed ONLY if the customer explicitly opted in at order placement.
- **Source:** wiki/docs/order-processing/order-lifecycle.md (Alignment: line-item states)
- **Test approach:** Order with 2 items, 1 in stock: partial_shipment=false → hold; partial_shipment=true → ship available

---

## Inventory

### RULE-005: Soft reservation timeout
- **Category:** inventory
- **Statement:** Soft reservations expire after 30 minutes if not converted to hard reservation. ATP is restored on expiry.
- **Source:** wiki/docs/inventory/stock-reservation.md (Vision: key invariants)
- **Test approach:** Create soft reservation, wait 30+ min, verify ATP restored

### RULE-006: ATP calculation
- **Category:** inventory
- **Statement:** Available-to-Promise (ATP) = Physical Stock − Hard Reservations − Soft Reservations. ATP cannot go negative.
- **Source:** wiki/docs/inventory/stock-reservation.md (Vision: key invariants)
- **Test approach:** Set stock=10, add 3 hard + 2 soft reservations, verify ATP=5. Attempt to reserve 6 → fail.

### RULE-007: Hard reservation requires payment
- **Category:** inventory
- **Statement:** A hard reservation can only be created if (a) a soft reservation exists for that order AND (b) payment is confirmed.
- **Source:** wiki/docs/inventory/stock-reservation.md (Vision: two-phase)
- **Test approach:** Attempt hard reserve without soft (fail), with soft but no payment (fail), with both (success)

### RULE-008: Oversell prevention
- **Category:** inventory
- **Statement:** The system MUST NOT allow soft reservation when ATP ≤ 0 (unless backorder is explicitly enabled for that SKU).
- **Source:** wiki/docs/inventory/stock-reservation.md (Vision: overselling prevention)
- **Test approach:** Set ATP=0, attempt reservation with backorder=false (fail), backorder=true (success with backorder flag)

### RULE-009: Backorder FIFO
- **Category:** inventory
- **Statement:** Backorders are fulfilled in FIFO order based on original order timestamp. No priority override.
- **Source:** wiki/docs/inventory/stock-reservation.md (Vision: backorder handling)
- **Test approach:** Create 3 backorders at T1, T2, T3. Restock arrives. Verify allocation order matches T1→T2→T3.

---

## Shipping

### RULE-010: Shipping cutoff
- **Category:** shipping
- **Statement:** Orders placed after 2:00 PM local warehouse time (standard service) ship on the next business day.
- **Source:** wiki/docs/shipping/carrier-selection.md (Vision: cutoff rules)
- **Test approach:** Order at 1:59 PM → ship today; order at 2:01 PM → ship tomorrow

### RULE-011: Dimensional weight calculation
- **Category:** shipping
- **Statement:** Billable weight = max(actual weight, dimensional weight). Dimensional weight = (L × W × H) / carrier-specific divisor.
- **Source:** wiki/docs/shipping/carrier-selection.md (Reality: dim weight divisor)
- **Test approach:** Package 20×20×20 in, 5 lbs. UPS divisor=139. Dim weight = 8000/139 = 57.5 lb. Billable = 58 lb (not 5).

### RULE-012: Free shipping threshold
- **Category:** shipping
- **Statement:** Orders with subtotal ≥ $50 (before tax, after discounts) qualify for free standard shipping.
- **Source:** Business requirement (configurable threshold)
- **Test approach:** Order $49.99 → shipping charged; $50.00 → free standard shipping

### RULE-013: Residential surcharge
- **Category:** shipping
- **Statement:** Deliveries to residential addresses incur a carrier surcharge ($4-6 depending on carrier). Commercial addresses do not.
- **Source:** wiki/docs/shipping/carrier-selection.md (Reality: residential detection)
- **Test approach:** Same package to residential vs commercial address → residential rate is $4-6 higher

---

## Payments

### RULE-014: Authorization before capture
- **Category:** payments
- **Statement:** Payment MUST be authorized at order placement and captured only at shipment time. Authorization hold expires after 7 days.
- **Source:** Industry standard (Stripe payment intents pattern)
- **Test approach:** Verify auth at placement, capture at ship, attempt capture after 7-day expiry (fail + re-auth)

### RULE-015: Refund ceiling
- **Category:** payments
- **Statement:** Total refunds for an order cannot exceed the original captured amount.
- **Source:** PCI-DSS / payment processor constraint
- **Test approach:** Capture $100, attempt refund $101 → reject. Refund $50 + $50 → accept. Refund $50 + $51 → reject.

---

## Summary

| Category | Rules | Coverage |
|----------|-------|----------|
| order-processing | 4 | Core lifecycle + fraud |
| inventory | 5 | Reservation + backorder |
| shipping | 4 | Cutoff + rates + threshold |
| payments | 2 | Auth/capture + refunds |
| **Total** | **15** | |
