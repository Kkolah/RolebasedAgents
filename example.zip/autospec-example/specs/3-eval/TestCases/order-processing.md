# Test Cases — Order Processing

> Format: Given/When/Then. Each test maps to a business rule.

---

### TC-ORD-001: Order below fraud threshold confirms immediately
- **Given:** Customer places order with total = $999.99
- **When:** Payment is authorized successfully
- **Then:** Order status transitions to CONFIRMED without fraud review hold
- **Rule:** RULE-001

### TC-ORD-002: Order above fraud threshold requires review
- **Given:** Customer places order with total = $1,000.01
- **When:** Payment is authorized successfully
- **Then:** Order status remains PLACED with fraud_review_required = true
- **Rule:** RULE-001

### TC-ORD-003: Cancel within 30-minute window succeeds
- **Given:** Order in CONFIRMED state, placed 29 minutes ago, pick not started
- **When:** Customer requests cancellation
- **Then:** Order status → CANCELLED, soft reservation released, payment auth voided
- **Rule:** RULE-002

### TC-ORD-004: Cancel after 30-minute window fails
- **Given:** Order in CONFIRMED state, placed 31 minutes ago
- **When:** Customer requests cancellation
- **Then:** Cancellation rejected with error "Cancellation window expired"
- **Rule:** RULE-002

### TC-ORD-005: Cancel shipped order fails
- **Given:** Order in SHIPPED state
- **When:** Customer requests cancellation
- **Then:** Cancellation rejected with error "Cannot cancel shipped order. Please initiate a return."
- **Rule:** RULE-003

### TC-INV-006: Soft reservation expires and restores ATP
- **Given:** Product with physical_stock=10, soft_reserved=2 (ATP=8). Reservation created 31 minutes ago.
- **When:** Reservation expiry job runs
- **Then:** soft_reserved decremented by expired quantity. ATP restored to 10.
- **Rule:** RULE-005

### TC-INV-007: ATP prevents overselling
- **Given:** Product with physical_stock=5, hard_reserved=3, soft_reserved=2 (ATP=0). Backorder=false.
- **When:** New order attempts to reserve 1 unit
- **Then:** Reservation fails with error "Insufficient stock". Order not confirmed.
- **Rule:** RULE-006, RULE-008

### TC-INV-008: Backorder accepted when enabled
- **Given:** Product with ATP=0, backorder_allowed=true
- **When:** New order attempts to reserve 1 unit
- **Then:** Reservation created with type=BACKORDER, order confirmed with estimated_ship_date populated
- **Rule:** RULE-008

### TC-SHIP-009: Order before cutoff ships same day
- **Given:** Order confirmed at 1:59 PM warehouse local time. Carrier cutoff = 2:00 PM.
- **When:** Shipping service processes the order
- **Then:** Ship date = today (same business day)
- **Rule:** RULE-010

### TC-SHIP-010: Order after cutoff ships next business day
- **Given:** Order confirmed at 2:01 PM warehouse local time (Friday). Carrier cutoff = 2:00 PM.
- **When:** Shipping service processes the order
- **Then:** Ship date = next Monday (next business day, skipping weekend)
- **Rule:** RULE-010

---

## Coverage Summary

| Category | Test Cases | Rules Covered |
|----------|-----------|---------------|
| Order Processing | 5 | RULE-001, 002, 003 |
| Inventory | 3 | RULE-005, 006, 008 |
| Shipping | 2 | RULE-010 |
| **Total** | **10** | **7 of 15 rules** |
