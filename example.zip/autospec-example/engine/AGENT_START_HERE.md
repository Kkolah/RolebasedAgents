# AutoSpec Example — E-Commerce Order Fulfillment

```
autospec-example/
├── CLAUDE.md              Agent entry point
├── goal.md                Mission definition
├── justfile               Task runner
├── engine/
│   ├── process/           Paradigms + 5 role playbooks
│   ├── backlogs/          Improvement items (tooling, validation, process)
│   └── sessions/          Session output folders (NNNN-role/)
├── scripts/
│   └── session/           session_start.py, validate_session.py
├── wiki/docs/             Grounded domain knowledge (V/R/A layers)
│   ├── order-processing/
│   ├── inventory/
│   └── shipping/
├── specs/                 Velocity V2 specification artifacts
│   ├── 1-initial/         Rules.md, PRD.md
│   ├── 2-design/          Architecture.md, DBDesign.md
│   ├── 3-eval/            TestCases/
│   └── governance/        ForbiddenZones.md, AllowedPatterns.md
└── raw/                   Landing zone for research downloads
```

## Pipeline

```
Sources (web search, public APIs, documentation)
       ↓
AutoSpec research loops (autonomous, role-based)
  5 roles: Core Worker → Spec Writer → Reviewer → Backlog Worker → Goal Alignment
       ↓
wiki/docs/ (grounded domain knowledge with sources)
       ↓
specs/ (Velocity V2 format: Rules, Architecture, DB, Tests, Governance)
```
