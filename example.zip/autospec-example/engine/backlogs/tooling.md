# Backlogs — Tooling

Items related to tools, scripts, and automation.

Format: `### Title` → Root cause, Filed by, Impact, Simplification check, Status

---

(No items yet — friction encountered during sessions goes here)
