# Backlogs — Process

Items related to playbooks, paradigms, and workflow design.

Format: `### Title` → Root cause, Filed by, Impact, Simplification check, Status

---

(No items yet — process friction encountered during sessions goes here)
