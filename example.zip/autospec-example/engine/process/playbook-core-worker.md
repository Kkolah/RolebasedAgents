# Playbook — Core Worker

> Job: Produce grounded wiki knowledge from domain sources.

## Phase 1: Understand Context

1. Read `goal.md` — understand the full mission scope
2. Read top tasks printed by `session_start.py`
3. Check what ALREADY EXISTS on your topic:
   - Read existing wiki pages in the relevant category
   - Identify the GAP you'll fill (don't repeat existing work)

## Phase 2: Research

### 2.1 Vision Sources (how should it work?)
- Industry standards (PCI-DSS, shipping protocols, e-commerce best practices)
- Platform documentation (Stripe API, Shopify docs, carrier APIs)
- Web search for authoritative specifications

### 2.2 Reality Sources (how does it actually work?)
- Public API documentation and SDKs
- Open-source implementations (reference code)
- Web search for real-world patterns and edge cases

### 2.3 Alignment (where do they match/drift?)
- Compare vision vs. reality
- Document discrepancies — these are the most valuable findings

## Phase 3: Write Output

1. **findings.md** in your session folder:
   - Vision section (what standards/docs say)
   - Reality section (what implementations actually do)
   - Alignment section (gaps and drifts)

2. **Wiki pages** in `wiki/docs/<category>/`:
   - Each page has: content + `## Sources` section with links
   - Use V/R/A structure where applicable

3. **Backlog items** if you hit friction:
   - `engine/backlogs/tooling.md` — tool issues
   - `engine/backlogs/validation.md` — gate issues
   - `engine/backlogs/process.md` — process issues

## Phase 4: Validate

```bash
uv run python scripts/session/validate_session.py engine/sessions/<your-folder>/
```
