# Playbook — Backlog Worker

> Job: Implement fixes and improvements from the backlog.

## Phase 1: Select Items

1. Read backlogs:
   - `engine/backlogs/tooling.md` — tool improvements
   - `engine/backlogs/validation.md` — validation gate fixes
   - `engine/backlogs/process.md` — process improvements
2. Pick highest-value items (prefer: validation > tooling > process)

## Phase 2: Implement

For each item:
1. Understand the root cause
2. Implement the fix (prefer automation over documentation)
3. Test that it works
4. Mark status: `REALIZED → <where the fix lives>`

## Phase 3: Maintenance

- Triage new PROPOSED items (add impact scores if missing)
- Archive items that sat PROPOSED for 10+ sessions without votes (PARK them)
- Check for stale IN-PROGRESS items

## Phase 4: Document & Validate

1. Write `report.md` documenting what you implemented
2. Validate:
```bash
uv run python scripts/session/validate_session.py engine/sessions/<your-folder>/
```
