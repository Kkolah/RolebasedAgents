# Playbook — Goal Alignment

> Job: Steer direction, measure progress, set priorities.

## Phase 1: Assess Current State

1. Read `goal.md` — understand the full mission scope
2. Measure actual state:
   ```bash
   find wiki/docs -name '*.md' | wc -l
   ```
3. For each category in goal.md's taxonomy: how many pages exist? How deep?

## Phase 2: Evaluate Coverage

- Which categories are empty or thin?
- Which have breadth but no depth?
- Are specs keeping up with wiki? (rules per category, test cases per category)

## Phase 3: Write Assessment

1. **state.md** — measurable progress against goal.md subgoals
2. **priorities.md** — ranked list of where effort should go next

## Phase 4: Steer

- Update backlogs to redirect future sessions toward gaps
- If system is breadth-starved: bias toward Core Worker tasks
- If system has breadth but thin specs: bias toward Spec Writer tasks

## Phase 5: Validate

```bash
uv run python scripts/session/validate_session.py engine/sessions/<your-folder>/
```
