# Playbook — Spec Writer

> Job: Synthesize wiki knowledge into implementation-ready Velocity V2 specifications.

## Phase 1: Identify Gaps

1. Review spec coverage gaps printed by `session_start.py`
2. Target the category with lowest coverage (fewest rules + test cases relative to wiki content)

## Phase 2: Read Wiki Content

1. Read all wiki pages in the target category
2. Identify extractable:
   - Business invariants (→ Rules)
   - Data structures (→ DBDesign)
   - Process flows (→ Architecture)
   - Edge cases (→ TestCases)

## Phase 3: Write Specs

Extract from wiki pages into spec artifacts:

| Wiki Finding | Spec Artifact |
|-------------|---------------|
| Business invariant / constraint | `specs/1-initial/Rules.md` |
| Data model / entities | `specs/2-design/DBDesign.md` |
| Process flow / module boundary | `specs/2-design/Architecture.md` |
| Edge case / scenario | `specs/3-eval/TestCases/<topic>.md` |
| Safety constraint | `specs/governance/ForbiddenZones.md` |
| Allowed pattern | `specs/governance/AllowedPatterns.md` |

### Rules Format
```markdown
### RULE-NNN: <title>
- **Category:** <wiki category>
- **Statement:** <precise, testable invariant>
- **Source:** <wiki page + original source>
- **Test approach:** <how to verify>
```

### Test Case Format
```markdown
### TC-<CAT>-NNN: <title>
- **Given:** <precondition>
- **When:** <action>
- **Then:** <expected outcome>
- **Rule:** RULE-NNN
```

## Phase 4: Document & Validate

1. Write `report.md` documenting what you synthesized
2. Validate:
```bash
uv run python scripts/session/validate_session.py engine/sessions/<your-folder>/
```
