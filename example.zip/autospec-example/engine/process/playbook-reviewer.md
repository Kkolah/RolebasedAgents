# Playbook — Reviewer

> Job: Audit prior sessions, find gaps, create backlog items.

## Phase 1: Select Target

1. `session_start.py` prints the target session to review
2. Read the target session's output files (findings.md or report.md)
3. Read the git diff for that session's changes

## Phase 2: Audit

For each change the target session made, evaluate:

1. **Grounding:** Does every claim have a source? Are sources real and clickable?
2. **Accuracy:** Do the wiki pages accurately represent what the sources say?
3. **Completeness:** Are there obvious gaps the session should have covered?
4. **Spec-readiness:** Are findings precise enough to derive rules/test cases?
5. **Process compliance:** Did the session follow its playbook?

## Phase 3: Improvement Items

For each gap found, create a backlog item:

- **Tool gaps** → `engine/backlogs/tooling.md`
- **Validation gaps** → `engine/backlogs/validation.md`
- **Process gaps** → `engine/backlogs/process.md`

Format:
```markdown
### <Title>
- **Root cause:** Why did this happen?
- **Filed by:** session NNNN
- **Impact score (creator):** High/Medium/Low
- **Simplification check:** How does fixing this make sessions simpler?
- **Status:** PROPOSED
```

## Phase 4: Write Report & Validate

1. Write `report.md` with findings
2. Validate:
```bash
uv run python scripts/session/validate_session.py engine/sessions/<your-folder>/
```
