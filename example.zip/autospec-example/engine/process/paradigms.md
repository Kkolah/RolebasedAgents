# Paradigms — The Governing Principles

> Every role reads this before their playbook. These are non-negotiable. If a decision contradicts a paradigm, the paradigm wins.

---

## The Enforcement Hierarchy

How to make agents actually do the right thing, ranked by reliability:

```
1. VALIDATION — gate fails if not done. Agent CANNOT pass without it.
2. TOOL       — makes it automatic. Agent can't NOT do it.
3. REFLECTION — report section forces articulation. Reviewer catches lies.
4. PROCESS    — written instruction. Agent may skip it. LAST RESORT.
```

Each level is strictly more reliable than the one below.

**The test:** If your proposed fix is "add a note to the playbook saying agents should..." → STOP. Can you validate it? Can you automate it? Can you at least force the agent to reason about it in the report?

---

## Only What's Measured Gets Done

Written instructions get skipped. Script output gets followed. Gate failures get fixed.

- Every desired behavior needs a validator check
- If a gate can't detect it, the behavior is aspirational (not real)
- Aspirational goals either become measurable or get deleted

---

## Simplification Over Addition

Every change must make the system SIMPLER, not more complex. New things must earn their place.

- Adding a step? Something else must be removed or automated away.
- Adding a rule? It must replace a judgment call that was causing errors.
- Adding a tool? It must eliminate manual work, not add a new thing to learn.

---

## Separation of Concerns

Each role has ONE job. Mixing jobs creates conflicts of interest.

| Role | Job | NOT their job |
|------|-----|---------------|
| Core Worker | Produce grounded wiki knowledge | Fix tools, improve process, set priorities |
| Spec Writer | Synthesize wiki into implementation specs | Produce new research, fix tools |
| Reviewer | Find gaps and create backlog items | Implement fixes, set direction |
| Backlog Worker | Implement fixes and maintain | Produce wiki content, set priorities |
| Goal Alignment | Steer direction, measure progress | Write wiki pages, fix tools |

---

## Three Layers (Vision / Reality / Alignment)

Every research output compares what SHOULD be (vision) with what IS (reality) and documents where they differ (alignment).

| Layer | Question | Where to find it |
|-------|----------|-----------------|
| Vision | How should it work? | Industry best practices, platform docs, standards |
| Reality | How does it work? | API documentation, source code, runtime behavior |
| Alignment | Where do they match/drift? | Comparison of above — the most valuable output |

**Drifts are the most valuable findings.** They're what engineers trip over.

---

## Progressive Disclosure

The wiki is a hierarchy. Every parent page summarizes its children.

- Root `index.md` = 80% of the picture in one page
- Category index = full picture for that topic
- Leaf pages = deep detail with sources

---

## Grounded Claims Only

Every assertion has a source. No "it seems" or "likely" without evidence.

- Every wiki page has a `## Sources` section with clickable links
- If a claim has no source link, it's ungrounded and may be hallucinated
- **Use web search to verify any industry standard or regulatory claim before writing it into wiki.**

---

## Token Discipline

Agents must minimize token waste. Context window is finite.

- **Do NOT use TodoWrite for tasks with fewer than 4 steps.**
- Prefer short, targeted tool calls over exploratory ones.
- Don't re-read files you already have in context.

---

## Random Review Prevents Gaming

The dice ensures any session might be reviewed. All roles get reviewed.

**The incentive:** Always do your best work because you don't know when the Reviewer is watching.

---

## Backlogs Are the Improvement Engine

- Friction → backlog item (with root cause)
- Backlog item → voted on by multiple roles
- Highest-priority items → implemented by Backlog Worker
- Implemented → REALIZED with citation

**The lifecycle:** `PROPOSED → IN-PROGRESS → REALIZED → archived`

---

## Iterative End-to-End Delivery

Build a simplified but fully complete version first. Use real data to deepen knowledge.

- The first pass covers ALL categories at surface level
- The second pass deepens the widest gaps
- Goal Alignment enforces breadth-first exploration

---

## Velocity-Ready Output

Wiki pages capture domain knowledge. Spec artifacts make that knowledge actionable.

The pipeline: **Research → Wiki → Specs → Implementation**

```
Core Workers produce wiki pages (domain knowledge with sources)
         ↓
Spec Writers synthesize into Velocity artifacts (Rules, Architecture, Tests, Governance)
         ↓
Implementation agents consume specs to produce correct code
```

**The test:** Can a coding agent implement the feature from `specs/` alone, without reading `wiki/docs/`? If not, the spec is incomplete.
