## Step 1: BEFORE DOING ANYTHING ELSE -> FIRST Roll the dice

```bash
uv run python scripts/session/session_start.py
```

This assigns your role (Core Worker 45%, Spec Writer 15%, Reviewer 15%, Backlog Worker 15%, Goal Alignment 10%), creates your session folder, and verifies tools. Follow the printed instructions.

Then verify MCP tools on first use:
- **Perplexity** — `mcp__perplexity__ask_search_ai` (any test query)

## Step 2: Read paradigms + your playbook

1. `engine/process/paradigms.md` — governing principles (ALL roles read this)
2. Your role-specific playbook (printed by session_start.py)

## Step 3: Execute your role

Follow your playbook. When done, validate:

```bash
uv run python scripts/session/validate_session.py <your-session-folder>/
```

## The two rules

1. If you hit friction, create a backlog item in `engine/backlogs/` (tooling, validation, or process).
2. BEFORE you start ANY task ensure you have a deep and absolute understanding. Research first — implement after you've exhausted all research angles.
