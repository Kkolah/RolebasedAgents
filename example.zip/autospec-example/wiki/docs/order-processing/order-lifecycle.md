# Order Lifecycle

## Vision

An order progresses through well-defined states with strict transition rules. Each transition is triggered by a specific event and may be gated by business rules (fraud review, stock availability).

### State Machine

```
PLACED → CONFIRMED → PROCESSING → SHIPPED → DELIVERED → CLOSED
  ↓          ↓           ↓
CANCELLED  CANCELLED   (cannot cancel after pick)
```

### Transition Rules

| From | To | Trigger | Gate |
|------|----|---------|------|
| PLACED | CONFIRMED | Payment authorized | Fraud score < threshold |
| PLACED | CANCELLED | Customer request OR fraud reject | Within 30 min of placement |
| CONFIRMED | PROCESSING | Inventory reserved (hard) | Stock available |
| CONFIRMED | CANCELLED | Customer request | Before pick begins |
| PROCESSING | SHIPPED | Carrier pickup scan | Label generated |
| SHIPPED | DELIVERED | Final delivery scan | — |
| DELIVERED | CLOSED | 14-day return window expires | No open RMA |

## Reality

Most e-commerce platforms implement a simplified version:

- **Shopify**: Uses `fulfillment_status` (unfulfilled, partial, fulfilled) separate from `financial_status` (pending, authorized, paid, refunded). No explicit PROCESSING state.
- **Stripe**: Payment intents track authorization separately from capture. Supports partial captures.
- **WooCommerce**: States are on-hold, processing, completed, cancelled, refunded.

Key differences from the vision:
- Partial fulfillment creates split states (some items shipped, some not)
- Payment capture is decoupled from order state in most systems
- "Processing" often conflates inventory reservation + pick + pack

## Alignment

| Aspect | Vision | Reality | Gap |
|--------|--------|---------|-----|
| State granularity | 7 explicit states | 4-5 states (varies by platform) | Our model needs PROCESSING split into RESERVED + PICKING + PACKED |
| Cancellation window | Time-based (30 min) | Event-based (before pick) | Use both: time-based hard cap + event-based soft cap |
| Partial shipment | Implied via line-item states | First-class concept in Shopify/Stripe | Must support order-level AND line-item-level states |
| Return window | Fixed 14 days | Configurable per merchant/product | Make configurable with 14-day default |

## Sources

- [Shopify Order API](https://shopify.dev/docs/api/admin-rest/2024-01/resources/order) — order states and transitions
- [Stripe Payment Intents](https://docs.stripe.com/api/payment_intents) — authorization vs capture lifecycle
- [WooCommerce Order Statuses](https://woocommerce.com/document/managing-orders/) — state machine reference
