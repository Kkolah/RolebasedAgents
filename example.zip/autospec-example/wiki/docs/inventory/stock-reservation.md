# Stock Reservation

## Vision

Inventory reservation prevents overselling by temporarily allocating stock to an order. Two-phase reservation ensures accuracy:

1. **Soft reservation** (at order placement): Decrements available-to-promise (ATP) count. Expires after timeout if not confirmed.
2. **Hard reservation** (at payment confirmation): Permanently allocates stock until fulfillment or cancellation.

### Key Invariants

- ATP = Physical stock - Hard reservations - Soft reservations
- A soft reservation MUST expire if not converted within the timeout window (default: 30 minutes)
- Hard reservation can only be created if soft reservation exists AND payment is confirmed
- Overselling is prevented at the soft reservation step (atomic decrement with floor check)

### Backorder Handling

When ATP reaches zero:
- If backorder allowed: accept order with estimated restock date
- If backorder not allowed: reject with "out of stock" immediately
- Backorder priority is FIFO based on order timestamp

## Reality

- **Shopify**: No explicit reservation concept. Stock is decremented at checkout completion (payment). Flash sales can oversell.
- **Amazon**: Uses "promise" model — estimates delivery date at cart time, confirms availability at order placement. Two-tier: FC-level vs network-level availability.
- **Stripe/Payments**: Unaware of inventory. Authorization only confirms payment ability, not stock.

Practical patterns observed:
- Most systems use optimistic concurrency (decrement and check, rollback on conflict)
- Redis-backed counters for high-throughput scenarios (flash sales)
- Periodic reconciliation between reservation system and warehouse management system (WMS)

## Alignment

| Aspect | Vision | Reality | Gap |
|--------|--------|---------|-----|
| Reservation phases | 2-phase (soft → hard) | Usually 1-phase (all-or-nothing at checkout) | 2-phase adds complexity but prevents cart-abandonment oversell |
| Timeout | Fixed 30 min | Varies: 10 min (flash sale) to 24h (B2B) | Make configurable per product/channel |
| Concurrency | Atomic decrement | Optimistic locking or Redis atomic ops | Implementation detail — both work |
| Backorder | FIFO queue | Often priority-based (loyalty tier, order value) | Support pluggable priority strategy |

## Sources

- [Shopify Inventory Levels API](https://shopify.dev/docs/api/admin-rest/2024-01/resources/inventorylevel) — stock tracking
- [AWS re:Invent 2019 — Inventory Reservation at Scale](https://www.youtube.com/watch?v=MEgapmr9t-g) — Amazon's reservation architecture
- [Redis DECR for inventory](https://redis.io/commands/decr/) — atomic counter pattern for high-throughput reservation
