# Carrier Selection

## Vision

When an order is ready to ship, the system selects the optimal carrier based on:

1. **Package dimensions** (weight, length × width × height)
2. **Destination zone** (domestic zones 1-8, international)
3. **Service level** (standard, expedited, overnight)
4. **Shipping cutoff time** (orders after cutoff ship next business day)
5. **Cost optimization** (cheapest carrier meeting SLA)

### Zone Calculation

Zones are determined by origin-destination ZIP code pairs. Each carrier defines zone maps differently:
- **USPS**: 1-9 zones based on distance
- **UPS/FedEx**: Similar zone structure, different boundaries
- **Regional carriers**: Typically zones 1-4 only

### Cutoff Rules

| Carrier | Cutoff (local warehouse time) | Ship Day |
|---------|-------------------------------|----------|
| Standard | 2:00 PM | Same day |
| Expedited | 4:00 PM | Same day |
| Overnight | 6:00 PM | Same day |
| After cutoff | — | Next business day |

### Rate Shopping

For each eligible carrier+service combination:
1. Calculate dimensional weight: `(L × W × H) / divisor` (varies by carrier)
2. Billable weight = max(actual weight, dimensional weight)
3. Look up rate from zone × weight matrix
4. Add surcharges (residential delivery, fuel, oversize)
5. Select cheapest option meeting delivery promise

## Reality

- **EasyPost API**: Multi-carrier rate shopping in a single API call. Returns sorted rates with estimated delivery dates. Handles zone lookup internally.
- **ShipStation**: Carrier-agnostic label generation. Supports automation rules (e.g., "use USPS for packages under 1 lb").
- **Shopify Shipping**: Carrier-calculated rates at checkout. Limited to configured carriers.

Key findings:
- Dimensional weight divisor: 139 (FedEx/UPS domestic), 166 (USPS), 5000 (metric)
- Most platforms cache rates for 15-60 minutes (carrier APIs are slow)
- Residential vs commercial address detection affects surcharges ($4-6 per package)

## Alignment

| Aspect | Vision | Reality | Gap |
|--------|--------|---------|-----|
| Rate shopping | Real-time per order | Cached rates (15-60 min TTL) | Cache is acceptable — rates don't change intra-day |
| Zone lookup | Per-carrier zone maps | Aggregator APIs handle internally | Delegate to carrier API, don't maintain zone tables |
| Cutoff time | Fixed per service level | Varies by warehouse + carrier pickup schedule | Must be configurable per warehouse-carrier pair |
| Dim weight | Single formula | Carrier-specific divisors | Store divisor per carrier in config |

## Sources

- [EasyPost Rate API](https://www.easypost.com/docs/api#rates) — multi-carrier rate comparison
- [UPS Dimensional Weight](https://www.ups.com/us/en/support/shipping-support/shipping-costs-estimates/dimensional-weight.page) — 139 divisor for domestic
- [USPS Zone Chart](https://postcalc.usps.com/DomesticZoneChart) — zone calculation by ZIP
- [ShipStation Automation Rules](https://help.shipstation.com/hc/en-us/articles/360025856192) — carrier selection automation
