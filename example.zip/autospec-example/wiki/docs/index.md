# E-Commerce Order Fulfillment — Wiki Index

Domain knowledge base for the order fulfillment system. Each category covers a distinct area of the order-to-delivery pipeline.

## Categories

| Category | Pages | Description |
|----------|-------|-------------|
| [order-processing](order-processing/) | 1 | Order lifecycle, states, validation |
| [inventory](inventory/) | 1 | Stock management, reservations, backorders |
| [shipping](shipping/) | 1 | Carrier selection, rates, tracking |
| payments/ | 0 | Authorization, capture, refunds (planned) |
| returns/ | 0 | RMA process, restocking (planned) |

## Architecture Overview

```
Customer places order
    ↓
Order validation (fraud check, address verification)
    ↓
Inventory reservation (soft → hard on payment)
    ↓
Payment authorization → capture at shipment
    ↓
Carrier selection (weight, zone, cutoff)
    ↓
Ship → Track → Deliver
    ↓
(Optional) Return → Restock → Refund
```

## Coverage Status

- **Researched:** order-processing, inventory, shipping
- **Planned:** payments, returns
- **Spec coverage:** 15 rules, 8 tables, 10 test cases
